#!/usr/bin/env python3
# Lesson 2 starter: load snapshot.json and append JSON-lines events
import json, os, time
inpath = os.path.expanduser('~/.config/witri/snapshot.json')
outpath = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
if not os.path.exists(inpath):
    print('run lesson 1 first')
    exit(1)
with open(inpath) as f:
    data = json.load(f)

# crude conversion: create one event per entry
events = []
entries = data.get('entries') if isinstance(data, dict) else data
if entries is None:
    entries = data

for e in entries:
    ev = {
        'ts': int(time.time()),
        'ssid': e.get('ssid',''),
        'bssid': e.get('bssid',''),
        'type': 'snapshot_entry'
    }
    events.append(ev)

os.makedirs(os.path.dirname(outpath), exist_ok=True)
with open(outpath,'a') as f:
    for ev in events:
        f.write(json.dumps(ev) + "\n")

print('Appended', len(events), 'events to', outpath)
