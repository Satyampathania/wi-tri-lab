#!/usr/bin/env python3
import argparse, time, os, json, subprocess
def run_once(iface):
    # call lesson1 solution to get snapshot, then lesson3 detection
    subprocess.call(['python3','lessons/01_scanner/solution.py', iface])
    subprocess.call(['python3','lessons/03_detection_rules/solution.py'])

if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--iface','-i', default='wlan0')
    ap.add_argument('--interval','-t', type=int, default=8)
    ap.add_argument('--learn', action='store_true')
    args = ap.parse_args()
    if args.learn:
        subprocess.call(['python3','lessons/01_scanner/solution.py', args.iface])
        import json, os
        snap = os.path.expanduser('~/.config/witri/snapshot.json')
        with open(snap) as f:
            d = json.load(f)
        entries = d.get('entries') if isinstance(d, dict) else d
        known = {}
        for e in entries:
            known.setdefault(e.get('ssid',''), []).append(e.get('bssid',''))
        os.makedirs(os.path.expanduser('~/.config/witri'), exist_ok=True)
        with open(os.path.expanduser('~/.config/witri/known_aps.json'),'w') as f:
            json.dump(known,f,indent=2)
        print('Learned', sum(len(v) for v in known.values()), 'bssids')
    else:
        while True:
            run_once(args.iface)
            time.sleep(args.interval)
