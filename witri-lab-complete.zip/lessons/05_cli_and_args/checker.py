#!/usr/bin/env python3
# basic check: start the wrapper in dry mode (--learn) to see known_aps.json
import subprocess, os
subprocess.call(['python3','lessons/05_cli_and_args/solution.py','--learn'])
if os.path.exists(os.path.expanduser('~/.config/witri/known_aps.json')):
    print("PASS: known_aps.json created")
else:
    print("FAIL: known_aps.json missing")
