#!/usr/bin/env python3
# improved: only notify new events since last run (tracking last timestamp)
import os, json, subprocess
events_file = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
state_file = os.path.expanduser('~/.config/witri/last_notify_ts')
if not os.path.exists(events_file):
    print('run previous lessons to generate events')
    exit(1)
last_ts = 0
if os.path.exists(state_file):
    with open(state_file) as f:
        try:
            last_ts = int(f.read().strip())
        except:
            last_ts = 0
new_ts = last_ts
with open(events_file) as f:
    for line in f:
        e = json.loads(line)
        if e.get('ts',0) > last_ts:
            title = f"W i - T r i: {e.get('type')}"
            body = f"{e.get('ssid')} {e.get('bssid','')}"
            if subprocess.call(['which','notify-send'], stdout=subprocess.DEVNULL)==0:
                subprocess.Popen(['notify-send', title, body])
            else:
                print(title, body)
            new_ts = max(new_ts, e.get('ts', new_ts))
with open(state_file,'w') as f:
    f.write(str(new_ts))
print('Notifications processed.')
