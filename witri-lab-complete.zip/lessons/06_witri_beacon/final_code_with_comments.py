#!/usr/bin/env python3
"""Wi-Tri Beacon — final, commented version (teaching edition)
Run: sudo python3 final_code_with_comments.py --iface wlan0 --learn
"""
import argparse, subprocess, re, json, os, time, logging
from collections import defaultdict
from shutil import which

# ASCII wiwi cat — tiny love note
WIWI = r"""
 .--.
|o_o |
|:_/ |
 //   \\ \\
(|  ^  | )  wiwi
/'\_   _/`\\
\\___)=(___/
"""

# Config
CFG_DIR = os.path.expanduser('~/.config/witri')
KNOWN = os.path.join(CFG_DIR, 'known_aps.json')
EVENTS = os.path.join(CFG_DIR, 'witri_beacon.log.events')
LOG = os.path.join(CFG_DIR, 'witri_beacon.log')
INTERVAL = 8
NOTIFY_CMD = 'notify-send'
FOOTER = "// Dedicated to the one who called me 'wii wii' — you know who you are."

os.makedirs(CFG_DIR, exist_ok=True)
logging.basicConfig(level=logging.INFO, filename=LOG, format='%(asctime)s %(levelname)s %(message)s')

print(WIWI)
print('Starting Wi-Tri Beacon — teaching edition')
print(FOOTER)

def run_scan(iface):
    try:
        r = subprocess.run(['iw','dev',iface,'scan'], capture_output=True, text=True, check=True)
        return r.stdout
    except subprocess.CalledProcessError:
        logging.error('iw scan failed')
        return ''
    except FileNotFoundError:
        logging.error('iw not installed')
        return ''

bss_re = re.compile(r"^BSS\s+([0-9a-fA-F:]{17})", flags=re.M)
ssid_re = re.compile(r"\tSSID: (.*)")

def parse(raw):
    entries = []
    lines = raw.splitlines()
    cur = None
    for line in lines:
        m = bss_re.match(line)
        if m:
            if cur: entries.append(cur)
            cur = {'bssid': m.group(1).lower(), 'ssid': ''}
            continue
        if cur is None: continue
        m = ssid_re.match(line)
        if m:
            cur['ssid'] = m.group(1)
    if cur: entries.append(cur)
    return entries

def load_known():
    if not os.path.exists(KNOWN): return {}
    with open(KNOWN) as f:
        return json.load(f)

def save_known(k):
    with open(KNOWN,'w') as f:
        json.dump(k,f,indent=2)

def detect(entries, known):
    events = []
    by_ssid = defaultdict(list)
    for e in entries:
        by_ssid[e.get('ssid','')].append(e)
    for ssid, lst in by_ssid.items():
        bssids = {x['bssid'] for x in lst}
        if len(bssids) > 1:
            events.append({'ts':int(time.time()), 'type':'duplicate_ssid','ssid':ssid,'bssids':list(bssids)})
        for x in lst:
            if ssid not in known or x['bssid'] not in known.get(ssid,[]):
                events.append({'ts':int(time.time()), 'type':'unknown_bssid','ssid':ssid,'bssid':x['bssid']})
    return events

def notify(ev):
    msg = f"{ev.get('type')} - {ev.get('ssid')} {ev.get('bssid','')}"
    if which(NOTIFY_CMD):
        try:
            subprocess.Popen([NOTIFY_CMD, 'Wi-Tri Beacon', msg])
        except Exception:
            logging.debug('notify failed')
    else:
        print('NOTIFY:', msg)

if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--iface','-i',required=True)
    ap.add_argument('--interval','-t',type=int, default=INTERVAL)
    ap.add_argument('--learn', action='store_true')
    ap.add_argument('--no-notify', action='store_true')
    args = ap.parse_args()

    if args.learn:
        raw = run_scan(args.iface)
        entries = parse(raw)
        known = {}
        for e in entries:
            known.setdefault(e.get('ssid',''), []).append(e.get('bssid',''))
        save_known(known)
        print('Learned', sum(len(v) for v in known.values()), 'bssids')
        raise SystemExit(0)

    while True:
        raw = run_scan(args.iface)
        if not raw:
            time.sleep(args.interval)
            continue
        entries = parse(raw)
        known = load_known()
        events = detect(entries, known)
        if events:
            with open(EVENTS,'a') as ef:
                for ev in events:
                    ef.write(json.dumps(ev) + "\n")
                    print('EVENT:', ev)
                    if not args.no_notify:
                        notify(ev)
        time.sleep(args.interval)
