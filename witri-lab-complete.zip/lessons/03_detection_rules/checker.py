#!/usr/bin/env python3
# Basic check: events file must contain at least one 'unknown_bssid' or 'duplicate_ssid'
import os
p = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
if not os.path.exists(p):
    print("FAIL: no events. Run lesson 3 starter.")
    exit(1)
with open(p) as f:
    s = f.read()
if 'unknown_bssid' in s or 'duplicate_ssid' in s:
    print("PASS: events contain detection types.")
else:
    print("WARN: events present but no detection types found. Manually verify.")
