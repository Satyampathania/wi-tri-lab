# Python Basics — ultra-condensed
print('hi')                -> prints
variables: a = 5
lists: arr = [1,2,3]
dicts: d = {'k':'v'}
loops: for x in arr: print(x)
functions: def f(x): return x*2
import modules: import re, subprocess, json
tips:
- practice typing code
- read errors; they're clues
