#!/usr/bin/env python3
# improved: tag duplicates and write events
import json, os, time
from collections import defaultdict
inpath = os.path.expanduser('~/.config/witri/snapshot.json')
outpath = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
if not os.path.exists(inpath):
    print('run lesson 1 first')
    exit(1)
with open(inpath) as f:
    data = json.load(f)
entries = data.get('entries') if isinstance(data, dict) else data

by_ssid = defaultdict(list)
for e in entries:
    by_ssid[e.get('ssid','')].append(e)

events = []
for ssid, lst in by_ssid.items():
    bssids = {x['bssid'] for x in lst}
    if len(bssids) > 1:
        events.append({'ts': int(time.time()), 'type': 'duplicate_ssid', 'ssid': ssid, 'bssids': list(bssids)})
    for x in lst:
        events.append({'ts': int(time.time()), 'type': 'seen_bssid', 'ssid': ssid, 'bssid': x['bssid']})

os.makedirs(os.path.dirname(outpath), exist_ok=True)
with open(outpath,'a') as f:
    for ev in events:
        f.write(json.dumps(ev) + "\n")
print('Wrote', len(events), 'events')
