# Wireless basics
- SSID: network name
- BSSID: MAC of access point
- Channel/freq: which radio frequency
- Signal dBm: negative numbers; closer to 0 = stronger
- Evil twin: fake AP mimicking SSID to trick clients
