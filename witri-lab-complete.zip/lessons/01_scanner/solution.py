#!/usr/bin/env python3
# Solution: more robust pairing and timestamp
import sys, subprocess, re, json, os, time
iface = sys.argv[1] if len(sys.argv)>1 else 'wlan0'

p = subprocess.run(['iw','dev',iface,'scan'], capture_output=True, text=True)
if p.returncode != 0:
    print('Scan failed. run with sudo and a valid iface')
    sys.exit(1)
raw = p.stdout

bss_re = re.compile(r"^BSS\s+([0-9a-fA-F:]{17})", flags=re.M)
ssid_re = re.compile(r"\tSSID: (.*)")

lines = raw.splitlines()
entries = []
current = None
for line in lines:
    m = bss_re.match(line)
    if m:
        if current:
            entries.append(current)
        current = {'bssid': m.group(1).lower(), 'ssid': ''}
        continue
    if current is None:
        continue
    m = ssid_re.match(line)
    if m:
        current['ssid'] = m.group(1)

if current:
    entries.append(current)

out_dir = os.path.expanduser('~/.config/witri')
os.makedirs(out_dir, exist_ok=True)
with open(os.path.join(out_dir,'snapshot.json'),'w') as f:
    json.dump({'ts': int(time.time()), 'entries': entries}, f, indent=2)
print('Saved', len(entries), 'entries')
