#!/usr/bin/env python3
import os, json
p = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
if not os.path.exists(p):
    print("FAIL: events file missing. Run lesson 2 starter or solution.")
    exit(1)
with open(p) as f:
    lines = [l.strip() for l in f if l.strip()]
if not lines:
    print("FAIL: events file empty.")
    exit(1)
print("PASS: events file has", len(lines), "lines.")
