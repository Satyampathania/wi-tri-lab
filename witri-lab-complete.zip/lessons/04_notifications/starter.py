#!/usr/bin/env python3
import os, json, subprocess
events_file = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
if not os.path.exists(events_file):
    print('run previous lessons to generate events')
    exit(1)
with open(events_file) as f:
    lines = [l.strip() for l in f if l.strip()]
for l in lines[-10:]:
    e = json.loads(l)
    title = f"W i - T r i: {e.get('type')}"
    body = f"{e.get('ssid')} {e.get('bssid','')}"
    if subprocess.call(['which','notify-send'], stdout=subprocess.DEVNULL)==0:
        subprocess.Popen(['notify-send', title, body])
    else:
        print(title, body)
print('Notifications attempted for last entries.')
