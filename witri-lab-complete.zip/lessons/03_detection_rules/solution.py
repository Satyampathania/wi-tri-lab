#!/usr/bin/env python3
# same as starter but cleaner and dedup events
import json, os, time
from collections import defaultdict
snap = os.path.expanduser('~/.config/witri/snapshot.json')
known_file = os.path.expanduser('~/.config/witri/known_aps.json')
out = os.path.expanduser('~/.config/witri/witri_beacon.log.events')
with open(snap) as f:
    d = json.load(f)
entries = d.get('entries') if isinstance(d, dict) else d
known = {}
if os.path.exists(known_file):
    with open(known_file) as f:
        known = json.load(f)

events = []
by_ssid = defaultdict(list)
for e in entries:
    by_ssid[e.get('ssid','')].append(e)

seen = set()
for ssid, lst in by_ssid.items():
    bssids = {x['bssid'] for x in lst}
    if len(bssids) > 1:
        ev = {'ts':int(time.time()), 'type':'duplicate_ssid','ssid':ssid,'bssids':list(bssids)}
        events.append(ev)
    for x in lst:
        if ssid not in known or x['bssid'] not in known.get(ssid,[]):
            ev = {'ts':int(time.time()), 'type':'unknown_bssid','ssid':ssid,'bssid':x['bssid']}
            key = (ev['type'], ev['ssid'], ev.get('bssid',''))
            if key not in seen:
                seen.add(key)
                events.append(ev)

os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out,'a') as f:
    for ev in events:
        f.write(json.dumps(ev) + "\n")
print('Detected', len(events), 'events.')
