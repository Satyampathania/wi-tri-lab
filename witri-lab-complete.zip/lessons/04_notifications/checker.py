#!/usr/bin/env python3
# Check: last_notify_ts should be present after running solution
p = os.path.expanduser('~/.config/witri/last_notify_ts')
if os.path.exists(p):
    print("PASS: last_notify_ts exists.")
else:
    print("WARN: run solution to generate notifications (or run checker after creating events).")
