#!/usr/bin/env python3
import argparse, time, os, json
def run_once(iface):
    print("stub: run detection once for", iface)

if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--iface','-i', default='wlan0')
    ap.add_argument('--interval','-t', type=int, default=8)
    ap.add_argument('--learn', action='store_true')
    args = ap.parse_args()
    if args.learn:
        print("learn mode (stub)")
    else:
        run_once(args.iface)
        print("would sleep for", args.interval)
