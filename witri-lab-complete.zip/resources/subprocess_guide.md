# Running commands from Python
- subprocess.run(['cmd','arg'], capture_output=True, text=True)
- result.stdout contains output
- use check=True to raise on non-zero exit code
- good for: iw, ifconfig, arp, nmap, etc.
