#!/usr/bin/env python3
"""Starter: minimal wifi scanner. Edit this file.
Run: sudo python3 lessons/01_scanner/starter.py wlan0
"""
import sys, subprocess, re, json, os

iface = sys.argv[1] if len(sys.argv)>1 else 'wlan0'

p = subprocess.run(['iw','dev',iface,'scan'], capture_output=True, text=True)
if p.returncode != 0:
    print('Scan failed. run with sudo and a valid iface')
    sys.exit(1)

raw = p.stdout
# TODO: extract BSSID and SSID pairs
bss = re.findall(r"^BSS\s+([0-9a-fA-F:]{17})", raw, flags=re.M)
ssids = re.findall(r"\tSSID: (.*)", raw)

pairs = []
for b,s in zip(bss, ssids):
    pairs.append({ 'bssid': b.lower(), 'ssid': s })

out_dir = os.path.expanduser('~/.config/witri')
os.makedirs(out_dir, exist_ok=True)
with open(os.path.join(out_dir,'snapshot.json'),'w') as f:
    json.dump(pairs,f,indent=2)

print('Saved snapshot with', len(pairs), 'entries to', out_dir)
