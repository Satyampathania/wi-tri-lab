#!/usr/bin/env python3
# Simple checker: verifies snapshot.json exists and has entries
import os, json, sys
p = os.path.expanduser('~/.config/witri/snapshot.json')
if not os.path.exists(p):
    print("FAIL: snapshot.json not found. Run the starter with sudo and correct iface.")
    sys.exit(1)
with open(p) as f:
    data = json.load(f)
cnt = 0
if isinstance(data, dict) and 'entries' in data:
    cnt = len(data['entries'])
elif isinstance(data, list):
    cnt = len(data)
if cnt == 0:
    print("FAIL: snapshot.json contains no entries.")
    sys.exit(1)
print("PASS: snapshot.json present with", cnt, "entries.")
